#include<iostream>
#include "scanType.h"

treeNode* MakeIOFuncs();