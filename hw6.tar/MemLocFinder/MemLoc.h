#include "../scanType.h"

extern int foffset;
extern int goffset;

void MemLocSet(treeNode* node, SymbolTable* SymbolTable);

